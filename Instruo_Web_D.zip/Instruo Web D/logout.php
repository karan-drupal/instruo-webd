<?php

	session_start();
	$_SESSION['userlogin']="0";
	$_SESSION['sellerlogin']="0";
	$_SESSION['email']="";
	echo "<script> location.href='index.php'; </script>";
?>