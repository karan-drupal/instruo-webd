<?php

	session_start();
	$verify=(isset($_POST['verify']))?$_POST['verify']:"";
	$pid=(isset($_GET['pid']))?$_GET['pid']:"";
	include "include/config.php";
	$obj=new Database();
	$servername='servername';
	$username='username';
	$password='password';
	$database='database';
	$products=$obj->product();
	$book=$obj->booking();
	$conn=mysqli_connect($obj->$servername,$obj->$username,$obj->$password,$obj->$database);
	if(!$conn)
	{
		echo mysqli_error($conn);
		die();
	}
	if(strlen($verify)>0)
	{
		$sql="SELECT * FROM $products WHERE verificationcode='".$verify."'";
		if(!($res=mysqli_query($conn,$sql)))
		{
			echo mysqli_error($conn);
		}
		if(mysqli_num_rows($res)==1)
		{
			$row=mysqli_fetch_assoc($res);
			$insert="INSERT INTO $book (customeremail,selleremail,productid) VALUES('".$_SESSION['email']."','".$row['email']."','".$row['productid']."')";
			if(!mysqli_query($conn,$insert))
			{
				echo mysqli_error($conn);
				die();
			}
			echo "Item Successfully booked.";
			echo "<br>"."<a href='index.php'>Click here to see more products.</a>";
		}
		
	}
	else if(strlen($verify)==0)
	{

			$sql="SELECT * FROM $products WHERE productid='".$pid."'";
			if(!($res=mysqli_query($conn,$sql)))
			{
				echo mysqli_error($conn);
			}	
			$row=mysqli_fetch_assoc($res);
			$insert="INSERT INTO $book (customeremail,selleremail,productid) VALUES('".$_SESSION['email']."','".$row['email']."','".$row['productid']."')";
			if(!mysqli_query($conn,$insert))
			{
				echo mysqli_error($conn);
				die();
			}
			echo "Item Successfully booked.";
			echo "<br>"."<a href='index.php'>Click here to see more products.</a>";
		
	}
?>