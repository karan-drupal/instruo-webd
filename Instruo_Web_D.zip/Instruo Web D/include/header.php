<?php
	if(!isset($_SESSION['sellerlogin']))
	{
		$_SESSION['sellerlogin']="0";	
	}
	if(!isset($_SESSION['userlogin']))
	{
		$_SESSION['userlogin']="0";	
	}
?>

<div class="header-section">
			<!-- top_bg -->
						<div class="top_bg">
							
								<div class="header_top">
									<div class="top_right">
										<ul>
											<li><a href="contact.html">help</a></li>|
											<li><a href="contact.html">Contact</a></li>|
											<li><a href="checkout.html">Delivery information</a></li>
										</ul>
									</div>
									<div class="top_left">
										<h2><span></span> Call us : 032 2352 782</h2>
									</div>
										<div class="clearfix"> </div>
								</div>
							
						</div>
					<div class="clearfix"></div>
				<!-- /top_bg -->
				</div>
				<div class="header_bg">
						
							<div class="header">
								<div class="head-t">
									<div class="logo">
										<a href="index.php"><img src="images/logo.png"  class="img-responsive" alt=""> </a>
									</div>
										<!-- start header_right -->
									<?php

										if($_SESSION['userlogin']=="0" && $_SESSION['sellerlogin']=="0")
											{ 
												?>
									<div class="header_right">
										<div class="rgt-bottom">
											<div class="reg">
												<a href="login.php">LOGIN</a>
											</div>
											<div class="reg">
												<a href="register.php">REGISTER</a>
											</div>
											
										<div class="cart box_1">
											<a href="checkout.html">
												<h3> <span class="simpleCart_total">$0.00</span> (<span id="simpleCart_quantity" class="simpleCart_quantity">0</span> items)<img src="images/bag.png" alt=""></h3>
											</a>	
											<p><a href="javascript:;" class="simpleCart_empty">(empty card)</a></p>
											<div class="clearfix"> </div>
										</div>
										<div class="create_btn">
											<a href="#">CHECKOUT</a>
										</div>
										<div class="clearfix"> </div>
									</div>
									<!--<div class="search">
										<form>
											<input type="text" value="" placeholder="search...">
											<input type="submit" value="">
										</form>
									</div>--><?php } else
									{?> 
										<div class="header_right">
										<div class="rgt-bottom">
											<div class="reg">
												<a>WELCOME</a>
											</div>
											<div class="reg">
												<a href="logout.php">LOGOUT</a>
											</div>
										<?php if($_SESSION['sellerlogin']=="0"){  ?>	
										<div class="cart box_1">
											<a href="checkout.html">
												<h3> <span class="simpleCart_total">$0.00</span> (<span id="simpleCart_quantity" class="simpleCart_quantity">0</span> items)<img src="images/bag.png" alt=""></h3>
											</a>	
											<p><a href="javascript:;" class="simpleCart_empty">(empty card)</a></p>
											<div class="clearfix"> </div>
										</div>
										<div class="create_btn">
											<a href="checkout.html">CHECKOUT</a>
										</div> <?php } ?>
										<div class="clearfix"> </div>
									</div>
								<?php }?>
									<div class="clearfix"> </div>
								</div>
								<div class="clearfix"> </div>
							</div>
						</div>
					
				</div>