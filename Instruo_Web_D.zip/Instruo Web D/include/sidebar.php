<div class="sidebar-menu">
					<header class="logo1">
						<a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> 
					</header>
						<div style="border-top:1px ridge rgba(255, 255, 255, 0.15)"></div>
                           <div class="menu">
									<ul id="menu" >
										<li><a href="index.php"><i class="fa fa-tachometer"></i> <span>Home</span></a></li>
										 <li id="menu-academico" ><a href="#"><i class="fa fa-table"></i> <span> Events</span> <span class="fa fa-angle-right" style="float: right"></span></a>
										   <ul id="menu-academico-sub" >
										   <li id="menu-academico-avaliacoes" ><a href="displayproducts.php?val=mm">Mayday Mystery</a></li>
											<li id="menu-academico-avaliacoes" ><a href="displayproducts.php?val=webd">WebD</a></li>
											<li id="menu-academico-boletim" ><a href="displayproducts.php?val=ac">Access Denied</a></li>
											<li id="menu-academico-boletim" ><a href="displayproducts.php?val=otc">Ode to Code</a></li>
										  </ul>
										</li>
										 
									 </li>
									
									  
									</li>
								  </ul>
								</div>
							  </div>
							  <div class="clearfix"></div>		
							</div>