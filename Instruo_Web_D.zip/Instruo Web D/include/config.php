
<?php
    /*Database login details:- Make it read-only or hidden after uploading in server*/
   
    class Database
    {
        public $servername="localhost";
        public $username="root";
        public $password="";
        public $database="instruoWD";

        public function seller()
        {
        	return "seller";
        }
        public function user()
        {
        	return "user";
        }
        public function product()
        {
            return "products";
        }
        public function booking()
        {
            return "booking";
        }
        
    }

?>
