<?php



	$fname=isset($_POST['fname'])?$_POST['fname']:"";
	$lname=isset($_POST['lname'])?$_POST['lname']:"";
	$email=isset($_POST['email'])?$_POST['email']:"";
	$pass=isset($_POST['pass'])?$_POST['pass']:"";
	$confirmpass=isset($_POST['confirmpass'])?$_POST['confirmpass']:"";
	$userorseller=isset($_POST['userorseller'])?$_POST['userorseller']:"";

	if(strcmp($pass,$confirmpass)==0)
	{

	}
	else
	{
		echo "wrong";
		die();
	}
	include "include/config.php";
	$obj=new Database();
	$servername='servername';
	$username='username';
	$password='password';
	$database='database';
	$seller=$obj->seller();
	$user=$obj->user();
	$conn=mysqli_connect($obj->$servername,$obj->$username,$obj->$password,$obj->$database);
	if(!$conn)
	{
		echo mysqli_error($conn);
		die();
	}
	if(strcmp($userorseller,"Seller")==0)
	{
		$checkexisting="SELECT * FROM $seller WHERE email='".$email."'";
		if(mysqli_num_rows(mysqli_query($conn,$checkexisting))>0)
		{
			echo "Already registered";
			echo "<br/><a href='register.php'>Click here to go back to registration page</a>";
			die();
		}
		else
		{	
			$sql="INSERT INTO $seller (fname,lname,email,password) VALUES ('".$fname."','".$lname."','".$email."','".$pass."')";
			if(!mysqli_query($conn,$sql))
			{
				echo mysqli_error($conn);
				die();
			}
		}
	}
	else if(strcmp($userorseller,"User")==0)
	{
		$checkexisting="SELECT * FROM $user WHERE email='".$email."'";
		if(mysqli_num_rows(mysqli_query($conn,$checkexisting))>0)
		{
			echo "Already Registered.<br/><a href='register.php'>Click here to go back to registration page</a>";
			die();
		}
		else
		{	
			$sql="INSERT INTO $user (fname,lname,email,password) VALUES ('".$fname."','".$lname."','".$email."','".$pass."')";
			if(!mysqli_query($conn,$sql))
			{
				echo mysqli_error($conn);
				die();
			}
		}
	}
	echo "Successfully Registered.<br/><a href='sellerhome.php'>Click here to go to admin page</a>";
	mysqli_close($conn);

?>