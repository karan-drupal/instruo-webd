<?php



	session_start();
	$email=isset($_POST['email'])?$_POST['email']:"";
	$pass=isset($_POST['pass'])?$_POST['pass']:"";
	$userorseller=isset($_POST['userorseller'])?$_POST['userorseller']:"";

	include "include/config.php";
	$obj=new Database();
	$servername='servername';
	$username='username';
	$password='password';
	$database='database';
	$seller=$obj->seller();
	$user=$obj->user();
	$conn=mysqli_connect($obj->$servername,$obj->$username,$obj->$password,$obj->$database);
	if(!$conn)
	{
		echo mysqli_error($conn);
		die();
	}
	if(strcmp($userorseller,"Seller")==0)
	{	
		$sql="SELECT * FROM $seller WHERE email='".$email."' AND password='".$pass."'";
		if(!($res=mysqli_query($conn,$sql)))
		{
			echo mysqli_error($conn);
			die();
		}
		if(mysqli_num_rows($res)==1)
		{
			if(!isset($_SESSION['sellerlogin']) || $_SESSION['sellerlogin']=="0")
			{
				$_SESSION['userlogin']="0";
				$_SESSION['sellerlogin']="1";	
			}
			else if($_SESSION['userlogin']=="1")
			{
				$_SESSION['userlogin']="0";
				$_SESSION['sellerlogin']="1";
			}
			echo "login successfull as seller";
			echo "<script>location.href='sellerhome.php'; </script>";
		}
		else
		{
			echo "Invalid User.<br/><a href='login.php'>Click here to go back to login page</a>";
		}
		
	}
	else if(strcmp($userorseller,"User")==0)
	{
		$sql="SELECT * FROM $user WHERE email='".$email."' AND password='".$pass."'";
		if(!($res=mysqli_query($conn,$sql)))
		{
			echo mysqli_error($conn);
			die();
		}
		if(mysqli_num_rows($res)==1)
		{
			$row=mysqli_fetch_assoc();
			if(!isset($_SESSION['userlogin']) || $_SESSION['userlogin']=="0")
			{
				$_SESSION['userlogin']="1";
				$_SESSION['sellerlogin']="0";
				$_SESSION['email']=$row['email'];
			}
			else if($_SESSION['sellerlogin']=="1")
			{
				$_SESSION['email']=$row['email'];
				$_SESSION['sellerlogin']="0";
				$_SESSION['userlogin']="1";
			}
			echo "<script>location.href='displayproducts.php?val=otc'; </script>";
		}
		else
		{
			echo "Invalid User.<br/><a href='login.php'>Click here to go back to login page</a>";
		}
	}

	mysqli_close($conn);

?>